# Valheim Climbing Mod

A mod for Valheim that introduces a climbing mechanic, allowing players to climb vertical surfaces, walls, and cliffs.

<img alt="" src="https://rotceh999.github.io/ValheimModImg/img1.jpg">

## Features

*   **Vertical Climbing:** Approach a wall and press the Climb Key (default: `LeftAlt`) to start climbing.
*   **Stamina Management:** Climbing drains stamina. If you run out, you fall!
*   **Custom Animations:** Includes custom animations for climbing up and down/idle.
*   **Working Online:** Enjoy watching your friends climbing a tree and falling miserably!
*   **Configurable:** Customize climb speed, stamina drain, and keybindings.

## Usage

1.  Walk up to a vertical surface (wall, cliff, tree, etc.).
2.  Hold the **Climb Key** (Default: `LeftAlt`) to attach to the surface.
    *   *Optionally, enable "Toggle Mode" in the config to press once to attach/detach.*
3.  Use **W** to climb up and **S** to climb down.
4.  Use **A** and **D** to move laterally.
5.  Release the key (or press again in Toggle Mode) to let go.

## Configuration

There is a config file :

| Setting | Default | Description |
| :--- | :--- | :--- |
| **ClimbKey** | `LeftAlt` | The key to hold (or press) to climb. |
| **ClimKey2** | `None` | None by default but you can add an input to do key combination. |
| **ToggleClimbKey** | `false` | If true, pressing the key toggles climbing on/off instead of holding it. |
| **ClimbSpeedUp** | `1.0` | Speed multiplier when climbing upwards. |
| **ClimbSpeedDown** | `1.0` | Speed multiplier when climbing downwards. |
| **StaminaDrainPerSecond** | `2.0` | Amount of stamina drained per second while climbing. |

## Known Issues / Notes

*   Climbing on very complex or jagged geometry might be jittery.
*   Ensure you have stamina before attempting a long climb!

<img alt="" src="https://rotceh999.github.io/ValheimModImg/img2.jpg">